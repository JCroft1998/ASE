﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using GraphicsTools;

namespace UnitTestGraphics
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestCommands()
        {
            
        

        }
    }
}
