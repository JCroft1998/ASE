﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace GraphicsTools
{/// <summary>
/// This is the pens class which sets the Pencolor to a standard color of black and then it can be changed with the color chooser. 
/// </summary>
    public class Pens:Commands
   {/// <summary>
   /// Default color is black for the pen
   /// </summary>
        public static Pen PenColor = new Pen(Color.Black);

       
        
        /// <summary>
        /// This is a color dialog which allows the user to choose the color of the pen 
        /// </summary>
        
      public static void PenChooser()

        {
            ColorDialog colorDlg = new ColorDialog();
            colorDlg.AllowFullOpen = false;
            colorDlg.ShowHelp = true;
            colorDlg.Color = PenColor.Color;

            if (colorDlg.ShowDialog() == DialogResult.OK)
            {
                PenColor.Color = colorDlg.Color;
                
            }
        }



    }

   


   
}
