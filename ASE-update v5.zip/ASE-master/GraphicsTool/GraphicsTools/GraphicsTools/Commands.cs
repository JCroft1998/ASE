﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Drawing.Imaging;

namespace GraphicsTools
{
   public class Commands:MainForm
    {
        public Button btnBackColor;
        private ColorDialog colorDialog1;
        public static int stringSize = 5;

      

        

        /// <summary>
        /// This method draws the circle by passing in the parameter radius and drawing an ellipse
        /// </summary>
        /// <param name="radius"></param>
        public static void DrawCircle(int radius)
        {  // 

            Graphics g = Graphics.FromImage(Mybitmap);
            g.DrawEllipse(new Pen(Pens.PenColor.Color, PenWidth), xPos, yPos, radius, radius);
            Mypanel.Invalidate();
        }


        public static void drawstring(string input)
        {
            string DrawString = input;
            Graphics g = Graphics.FromImage(Mybitmap);
            Font myFont = new System.Drawing.Font("Helvetica", stringSize, FontStyle.Italic);
            Brush myBrush = new SolidBrush(System.Drawing.Color.Red);
            g.DrawString(DrawString, myFont,myBrush,50 ,50);
            
        }

       
            /// <summary>
            ///   This method draws a Triangle
            /// </summary>
            /// <param name="firstSide"></param>
            /// <param name="secondSide"></param>
            public static void DrawTriangle(int firstSide, int secondSide)
        {
            Point[] triPoints = new Point[3];
            triPoints[0] = new Point(xPos, yPos);
            triPoints[1] = new Point(firstSide + xPos, firstSide + yPos);
            triPoints[2] = new Point(triPoints[1].X - secondSide, triPoints[1].Y);
            Graphics g = Graphics.FromImage(Mybitmap);
            g.DrawPolygon(new Pen(Pens.PenColor.Color, PenWidth), triPoints);
            Mypanel.Invalidate();
        }
        /// <summary>
        /// This method draws a rectangle 
        /// </summary>
        /// <param name="width"></param>
        /// <param name="height"></param>
        public static void DrawRectangle(int width, int height)
        {
            Graphics g = Graphics.FromImage(Mybitmap);
            g.DrawRectangle(new Pen(Pens.PenColor.Color, PenWidth), xPos, yPos, width, height);
            Mypanel.Invalidate();
        }

        /// <summary>
        /// This method the line of the pen 
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public static void DrawPen(int x, int y)
        {
            Graphics g = Graphics.FromImage(Mybitmap);
            g.DrawLine(new Pen(Pens.PenColor.Color, PenWidth), new Point(xPos, yPos), new Point(x, y));
            PenPosition(x, y);
            Mypanel.Invalidate();
        }
        /// <summary>
        /// This method sets the pens position to the user input 
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public static void PenPosition(int x, int y)
        {
            xPos = x;
            yPos = y;
        }
/// <summary>
/// This resets the position of the pen to 0
/// </summary>
        public static void Reset()
        {
            xPos = 0;
            yPos = 0;
        }
/// <summary>
/// This method clears the graphics panel
/// </summary>

        public static void Clear()
        {
            Graphics g = Graphics.FromImage(Mybitmap);
            g.Clear(Color.White);
            Mypanel.Invalidate();
        }
        /// <summary>
        /// This method allows the user to change the color of the background of the panel
        /// </summary>
        public static void BackGroundColor()
        {
            
            ColorDialog colorDlg = new ColorDialog();
            colorDlg.AllowFullOpen = false;
            colorDlg.ShowHelp = true;
            colorDlg.Color = Mypanel.BackColor;

            if (colorDlg.ShowDialog()== DialogResult.OK)
            {
                Mypanel.BackColor = colorDlg.Color;
            }
        }
        /// <summary>
        /// This method allows you to create a image 
        /// </summary>
        public static void SaveImage()
        {
            SaveFileDialog Savedialog = new SaveFileDialog();
            if (Savedialog.ShowDialog() == DialogResult.OK)
            {
                int width = Convert.ToInt32(Mypanel.Width);
                int height = Convert.ToInt32(Mypanel.Height);
                Bitmap bmp = new Bitmap(width, height);
                Mypanel.DrawToBitmap(bmp, new Rectangle(0, 0, width, height));
                bmp.Save(Savedialog.FileName, ImageFormat.Bmp);

             
                
            }
        }
       
        /// <summary>
        /// This method saves the program as the file path
        /// </summary>
        public static void ProgramSave()
        {
            try
            {
                // Generates name:
                string generated = DateTime.Now.ToString("ddMMyyyy-hhmmss");
                string savePath = Directory.GetParent(Environment.CurrentDirectory).Parent.FullName + Path.DirectorySeparatorChar + "Programs" + Path.DirectorySeparatorChar + generated + ".txt";

                // Saves text:
                TextWriter write = new StreamWriter(savePath);
                write.Write(Mytextbox.Text);
                write.Close();

                MessageBox.Show("Program saved as: " + generated + ".txt");
            } catch(Exception)
            {

            }
        }
        /// <summary>
        /// This method loads the program 
        /// </summary>
        public static void ProgramLoad()
        {
            try
            {
                string loadPath = Directory.GetParent(Environment.CurrentDirectory).Parent.FullName + Path.DirectorySeparatorChar + "Programs" + Path.DirectorySeparatorChar;

                OpenFileDialog ofd = new OpenFileDialog();
                ofd.InitialDirectory = loadPath;

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    // Loads selected file:
                    string set = File.ReadAllText(ofd.FileName);
                    Mytextbox.Clear();
                    Mytextbox.AppendText(set);
                }
            }
            catch (Exception)
            {

            }
        }

     /// <summary>
     /// This method looks at all the lines in the richtext box and does the commands the user types in.
     /// </summary>
        public static void Run()
        {
            try
            {
                Reset();
                Clear();

                
                foreach(string line in Mytextbox.Lines)
                {
                   
                        DoCommand(line);
                    
                    
                   
                }
            } catch(Exception)
            {

            }
        }

        public static void ProgramCommand(string Program)
        {
            Program = Program.ToLower().Trim();
            string[] sSplit = Program.Split(' ');

            try
            {
                Program = sSplit[0].Trim();
                Input1 = Int32.Parse(sSplit[1].Trim());
                Input2 = Int32.Parse(sSplit[2].Trim());
                   
                
            }
            catch (Exception)
            {
               
        
            }
            try
            {
              
                

            }
            catch (Exception)
            {

                throw;
            }
        }

       
        /// <summary>
        /// This method splits the text box up using a split which is space, then if statements for each command.
        /// </summary>
        /// <param name="command"></param>
        public static void DoCommand(string command)
        {
            command = command.ToLower().Trim();
            string[] sSplit = command.Split(' ');

            try
            {
                Function = sSplit[0].Trim();
                valOne = Int32.Parse(sSplit[1].Trim());
                valTwo = Int32.Parse(sSplit[2].Trim());
            }
            catch (Exception)
            {
            }

            try
            {
                if (string.IsNullOrEmpty(Function))
                {
                    // Leave blank
                }

                else if (Function == "triangle" && int.TryParse(sSplit[1], out valOne) && int.TryParse(sSplit[2], out valTwo))
                {
                    DrawTriangle(valOne, valTwo);
                }

                else if (Function == "rectangle" && int.TryParse(sSplit[1], out valOne) && int.TryParse(sSplit[2], out valTwo))
                {
                    DrawRectangle(valOne, valTwo);
                }

                else if (Function == "circle" && int.TryParse(sSplit[1], out valOne))
                {
                    DrawCircle(valOne);
                }

                else if (Function == "moveto" && int.TryParse(sSplit[1], out valOne) && int.TryParse(sSplit[2], out valTwo))
                {
                    PenPosition(valOne, valTwo);
                }

                else if (Function == ("clear"))
                {
                    Clear();
                }

                else if (Function == ("reset"))
                {
                    Reset();
                }

                else if (Function == "drawto" && int.TryParse(sSplit[1], out valOne) && int.TryParse(sSplit[2], out valTwo))
                {
                    DrawPen(valOne, valTwo);
                }

                else if (Function == ("save"))
                {
                    ProgramSave();
                }

                else if (Function == ("load"))
                {
                    ProgramLoad();
                }

                else if (Function == ("run"))
                {
                    Run();
                }

                else if (Function == ("backgroundcolor"))
                {
                    BackGroundColor();
                }
                else if (Function == ("pencolor"))
                {
                    Pens.PenChooser();
                }
                else if (Function == ("brushcolor"))
                {
                    FillShapes.SolidColor();
                }

                else if (Function == ("fillcircle"))
                {
                    FillShapes.FillCircle(valOne);
                }
                else if (Function == ("fillrectangle"))
                {
                    FillShapes.FillRectangle(valOne, valTwo);
                }
                else if (Function == ("filltriangle"))
                {
                    FillShapes.FillTriangle(valOne, valTwo);
                }
                else if (Function == "penthickness")
                {
                    PenWidth = valOne;
                }
                else if (Function == "drawstring")
                {
                    drawstring(valOne.ToString());
                }
                else if (Function == "radius" && int.TryParse(sSplit[1], out valOne))
                {
                    DrawCircle(valOne);
                }
                else
                
                {
                    MessageBox.Show("Invalid command: " + command);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid command: " + command);
            }
        }

        private void InitializeComponent()
        {
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.btnBackColor = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBackColor
            // 
            this.btnBackColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackColor.Location = new System.Drawing.Point(689, 131);
            this.btnBackColor.Name = "btnBackColor";
            this.btnBackColor.Size = new System.Drawing.Size(75, 30);
            this.btnBackColor.TabIndex = 6;
            this.btnBackColor.Text = "Colour";
            this.btnBackColor.UseVisualStyleBackColor = true;
      
            // 
            // Commands
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(782, 440);
            this.Controls.Add(this.btnBackColor);
            this.Name = "Commands";
            this.Text = "";
            this.Controls.SetChildIndex(this.btnBackColor, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

       
    }
}
