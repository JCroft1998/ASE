﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace GraphicsTools
{
    public class Pens:Commands
    {
        Pen redpen = new Pen(Color.Red,3);
        Pen bluepen = new Pen(Color.Blue, 3);
    }
}
