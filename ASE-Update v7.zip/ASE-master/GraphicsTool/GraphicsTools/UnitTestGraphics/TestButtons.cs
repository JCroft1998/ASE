﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using GraphicsTools;

namespace UnitTestGraphics
{
    [TestClass]
    public class TestButtons
    {
        [TestMethod]
        public void TestCommands()
        {

            

        }
    }
}
