﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphicsTools
{
    class Commads:MainForm
    {
        
       public string PositionPen;
       public string PenDraw;
       public string Clear;
       public string ResetPen;
       public string save;










    }
}
