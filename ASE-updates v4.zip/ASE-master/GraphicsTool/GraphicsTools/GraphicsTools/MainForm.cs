﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;


namespace GraphicsTools
{
    public partial class MainForm : Form


    {   //Referencing classes 
        public static Bitmap Mybitmap;
        public static Panel Mypanel;
        public static RichTextBox Mytextbox;
        public static Pens MyPen;
        public static int xPos = 0, yPos = 0, PenWidth = 0, valOne = 0, valTwo = 0;
        public static int Input1 = 0, Input2 = 0;
        public static int Myint = 0; 
        public static string Function;
        public static string Program;
   

        public MainForm()
        {
            InitializeComponent();
            Mybitmap = new Bitmap(Size.Width, Size.Height);
            Mypanel = panel1;
            Mytextbox = richTextBox1;
        }



        /// <summary>
        /// Panel Painting Method 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImageUnscaled(Mybitmap, 0, 0);

            // Stops the panel from flashing:
            typeof(Panel).InvokeMember("DoubleBuffered", BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic, null, Mypanel, new object[] { true });
        }

        // Command strip menu shows a message box of the commands that can be used in the program
        private void commandsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Circle number\n" +
                "Resetpen \n" +
                "Rectangle number,number\n" +
                "Triangle number, number \n"
                +"Moveto number,number \n"
                + "Clear\n" +
                "Reset\n" +
                "Drawto number, number\n" +
                "Save\n" +
                "Run\n" +
                "Load", "Commands", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
        }

        /// <summary>
        /// This method will save the bitmap image
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Commands.ProgramSave();

        }

        private void btnBackColor_Click(object sender, EventArgs e)
        {
            Commands.BackGroundColor();
        }
        /// <summary>
        /// Pen Chooser Color
        ///
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            Pens.PenChooser();
        }
        /// <summary>
        /// Brush chooser dialog for the fill shapes 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSolidBrush_Click(object sender, EventArgs e)
        {
            FillShapes.SolidColor();
        }
        /// <summary>
        /// Saves the image of the shapes 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSaveImage_Click(object sender, EventArgs e)
        {
            Commands.SaveImage();
        }

       



        /// <summary>
        /// This method is executed when the enter button is pressed
        /// Includes the spliter for the txtbox command
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtCommand_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Commands.DoCommand(txtCommand.Text);
            }
        }

        /// <summary>
        /// This method clears the bitmap and repaints it white 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void btnClear_Click(object sender, EventArgs e)
        {
            Commands.Clear();
        }
        /// <summary>
        /// This method loads the program, it uses the commands class and uses the programLoad method()
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Commands.ProgramLoad();
        }
        /// <summary>
        /// This method allows the user to exit and displays a message to show a YES/NO option
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to close this application?","Exit",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)== System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }



    }
    }

