﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraphicsTools
{/// <summary>
/// This class is for filling shapes with color 
/// </summary>
    public class FillShapes:MainForm
    {
        public static SolidBrush Solidbrushcolor = new SolidBrush(Color.Red);

        /// <summary>
        /// This method creates a color chooser for the solid brush 
        /// </summary>
        public static void SolidColor()
        {
            ColorDialog colorDlg = new ColorDialog();
            colorDlg.AllowFullOpen = false;
            colorDlg.ShowHelp = true;
            colorDlg.Color = Solidbrushcolor.Color;

            if (colorDlg.ShowDialog() == DialogResult.OK)
            {
                Solidbrushcolor.Color = colorDlg.Color;
            }
        }
        public static void FillCircle(int radius)
        {  // 

            Graphics g = Graphics.FromImage(Mybitmap);
            g.FillEllipse(new SolidBrush(Solidbrushcolor.Color), xPos, yPos, radius, radius);
            Mypanel.Invalidate();
        }

        public static void FillRectangle(int width, int height)
        {
            Graphics g = Graphics.FromImage(Mybitmap);
            g.FillRectangle(new SolidBrush(Solidbrushcolor.Color), xPos, yPos, width, height);
            Mypanel.Invalidate();
        }

        public static void FillTriangle(int firstSide, int secondSide)
        {
            Point[] triPoints = new Point[3];
            triPoints[0] = new Point(xPos, yPos);
            triPoints[1] = new Point(firstSide + xPos, firstSide + yPos);
            triPoints[2] = new Point(triPoints[1].X - secondSide, triPoints[1].Y);
            Graphics g = Graphics.FromImage(Mybitmap);
            g.FillPolygon(new SolidBrush(Solidbrushcolor.Color), triPoints);
            Mypanel.Invalidate();
        }

    }

}
