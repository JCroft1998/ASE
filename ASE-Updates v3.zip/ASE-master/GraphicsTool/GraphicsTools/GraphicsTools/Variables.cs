﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphicsTools
{/// <summary>
/// This class stores the variables in a list 
/// </summary>
     public  class Variables:MainForm
    {
       static List<string>  intVariablesLst = new List<string>();
       
        public static void AddVariable(string varname, int varValue)
        {
            intVariablesLst.Add(varname + "," + varValue);
        }

        public static int GetVariable(string varName)
        {
            int answer = 0;
          

            foreach (string variable in intVariablesLst)
                
            {
                string[] splitter = variable.Split(',');
                if (splitter[0].Equals(varName))
                {

                   answer = Int32.Parse(splitter[0]);
                    break;
                }
             
            }
            return answer;
        }
    }

    
}
