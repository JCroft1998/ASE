﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using GraphicsTools;
namespace UnitTestPart2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void FillShape()
        {
            var FillShapes = new FillShapes();
        }
    }
}
