﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using GraphicsTools;

namespace UnitTestGraphics
{
    [TestClass]
    public class TestButtons
    {
        [TestMethod]
        public void TestCommands()
        {
           Assert.Fail();


        }
/// <summary>
/// This method will test the shapes and will pass the values into the shapes
/// </summary>
        public void Testshapes()
        {
            var commands = new Commands();

            Commands.DrawRectangle(100, 100);
            Commands.DrawCircle(100);
            Commands.DrawTriangle(300, 300);

            
        }
/// <summary>
/// Testing the Fill shapes 
/// </summary>
        public void TestFillShapes()
        {
            var fillshapes = new FillShapes();

            FillShapes.FillCircle(100);
            FillShapes.FillRectangle(100, 100);
            FillShapes.FillTriangle(400, 400);


        }



    }
}
